# -*- coding: utf-8 -*-
from SelfbotAPI_PC import *
from datetime import datetime
from time import sleep
from bs4 import BeautifulSoup
from humanfriendly import format_timespan,format_size,format_number,format_length
import time,random,sys,json,codecs,threading,glob,re,string,os,requests,subprocess,six,html5lib,urllib, urllib.parse,ast,pytz,urllib.request
import pafy
import time
import timeit
import wikipedia
import instagram
from random import randint
import tart
import simplejson,pyowm
#==============================================================================================================
botStart = time.time()
server = LineServer()
tokenOpen = codecs.open('token.json','r','utf-8')
token = json.load(tokenOpen)
with open("data.json","r") as fp:
    data = json.load(fp)
#==============================================================================================================
if server.APP_NAME == data["APP_NAME_PC"]:
    tokens = "TOKEN_PC"
elif server.APP_NAME == data["APP_NAME_IPAD"]:
    tokens = "TOKEN_IPAD"
elif server.APP_NAME == data["APP_NAME_CHROME"]:
    tokens = "TOKEN_CHROME"
else:
    print ("[ INFO ] INVALID APP NAME")
    exit()
#==============================================================================================================
if token[tokens] != "":
    try:
        client = LineClient(authToken=token[tokens])
    except:
        print ("[ INFO ] INVALID TOKEN")
        client = LineClient()
        token_ = token
        token_ = token
        token_[tokens] = str(client.authToken)
        f = codecs.open('token.json','w','utf-8')
        json.dump(token_, f, sort_keys=True, indent=4, ensure_ascii=False)
else:
    client = LineClient()
    token_ = token
    token_[tokens] = str(client.authToken)
    f = codecs.open('token.json','w','utf-8')
    json.dump(token_, f, sort_keys=True, indent=4, ensure_ascii=False)
client.log("Auth Token : " + str(client.authToken))
#==============================================================================================================
if tokens != "TOKEN_CHROME":
    channel = LineChannel(client)
    client.log("Channel Access Token : " + str(channel.channelAccessToken))
else:
    channel = None
#==============================================================================================================
readOpen = codecs.open("read.json","r","utf-8")
settingsOpen = codecs.open("temp.json","r","utf-8")
#==============================================================================================================
#GetInfo
clientProfile = client.getProfile()
clientSettings = client.getSettings()
clientPoll = LinePoll(client)
clientMID = client.profile.mid
call = LineCall(client)

contact = client.getProfile()
backup = client.getProfile()
backup.displayName = contact.displayName
backup.statusMessage = contact.statusMessage
backup.pictureStatus = contact.pictureStatus
#==============================================================================================
protectname = []
targets = []
#==============================================================================================
settings = {
  "autoJoin":False,
  "autoReject":{"status":True,"members":10},
  "autoAdd":False,
  "autoRead":False,
  "server":"VPS",
  "autotag":False,
  "responpm":False,
  "notag":False,
  "autotag":False,
  "commentBlack":{},
  "wblack":False,
  "dblack":False,
  "blacklist":{},
  "wblacklist":False,
  "dblacklist":False,
  "linkprotect":False,
  "inviteprotect":False,
  "Mprotection":False,
  "pname":{},
  "targets":{},
  "pro_name":{},
  "welcome":False,
  "welcomeimg":False,
  "winvite":False,
  "contact":False,
  "sticker1":False,
  "sticker":False,
  "chat":False,
}
myProfile = {
	"displayName": "",
	"statusMessage": "",
	"pictureStatus": ""
}
cctv = {
  "point":{},
  "cyduk":{},
  "sidermem":{}
}

#===============================================================================
user_agent = "Mozilla/5.0 (X11; U; Linux i586; de; rv:5.0) Gecko/20100101 Firefox/5.0","Mozilla/5.0 (X11; U; Linux amd64; rv:5.0) Gecko/20100101 Firefox/5.0 (Debian)", "Mozilla/5.0 (X11; U; Linux amd64; en-US; rv:5.0) Gecko/20110619 Firefox/5.0","Mozilla/5.0 (X11; Linux) Gecko Firefox/5.0", "Mozilla/5.0 (X11; Linux x86_64; rv:5.0) Gecko/20100101 Firefox/5.0 FirePHP/0.5","Mozilla/5.0 (X11; Linux x86_64; rv:5.0) Gecko/20100101 Firefox/5.0 Firefox/5.0", "Mozilla/5.0 (X11; Linux x86_64) Gecko Firefox/5.0","Mozilla/5.0 (X11; Linux ppc; rv:5.0) Gecko/20100101 Firefox/5.0","Mozilla/5.0 (X11; Linux AMD64) Gecko Firefox/5.0", "Mozilla/5.0 (X11; FreeBSD amd64; rv:5.0) Gecko/20100101 Firefox/5.0","Mozilla/5.0 (Windows NT 6.2; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0", "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:5.0) Gecko/20110619 Firefox/5.0","Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:5.0) Gecko/20100101 Firefox/5.0", "Mozilla/5.0 (Windows NT 6.1; rv:6.0) Gecko/20100101 Firefox/5.0","Mozilla/5.0 (Windows NT 6.1.1; rv:5.0) Gecko/20100101 Firefox/5.0", "Mozilla/5.0 (Windows NT 5.2; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0","Mozilla/5.0 (Windows NT 5.1; U; rv:5.0) Gecko/20100101 Firefox/5.0", "Mozilla/5.0 (Windows NT 5.1; rv:2.0.1) Gecko/20100101 Firefox/5.0","Mozilla/5.0 (Windows NT 5.0; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0","Mozilla/5.0 (Windows NT 5.0; rv:5.0) Gecko/20100101 Firefox/5.0"
#===============================================================================
myProfile["displayName"] = clientProfile.displayName
myProfile["statusMessage"] = clientProfile.statusMessage
myProfile["pictureStatus"] = clientProfile.pictureStatus  
#==============================================================================================================
read = json.load(readOpen)
settings = json.load(settingsOpen)
#==============================================================================================================
if settings["restartPoint"] != None:
    client.sendMessage(settings["restartPoint"], "「Done restarted」")
    settings["restartBot"] = None
#==============================================================================================================
def MENTION(to, nama):
    aa = ""
    bb = ""
    strt = int(0)
    akh = int(0)
    nm = nama
    myid = "ub0a437d8c41b2949e1de3f884ac32e02"
    for mm in nm:
      akh = akh + 6
      aa += """{"S":"""+json.dumps(str(strt))+""","E":"""+json.dumps(str(akh))+""","M":"""+json.dumps(mm)+"},"""
      strt = strt + 7
      akh = akh + 1
      bb += "@x \n"
    aa = (aa[:int(len(aa)-1)])
    text = bb
    try:
       client.sendMessage(to, text, contentMetadata={'MENTION':'{"MENTIONEES":['+aa+']}'}, contentType=0)
    except Exception as error:
       print(error)
#===========================
def _images_get_all_items(page):
    items = []
    while True:
        item, end_content = _images_get_next_item(page)
        if item == "no_links":
            break
        else:
            items.append(item) #Append all the links in the list named 'Links'
            page = page[end_content:]
    return items             
#{=========================================
#========================================================
## -*- Script Start -*- ##
def restartBot():
    print ("[ INFO ] BOT RESETTED")
    backupData()
    time.sleep(5)
    python = sys.executable
    os.execl(python, python, *sys.argv)
#==============================================================================================================
def autoRestart():
    if time.time() - botStart > int(settings["timeRestart"]):
        backupData()
        time.sleep(5)
        restartBot()
#==============================================================================================================
def logError(text):
    client.log("[ INFO ] ERROR : " + str(text))
    time_ = datetime.now()
    with open("errorLog.txt","a") as error:
        error.write("\n[%s] %s" % (str(time_), text))
#==============================================================================================================
def translate(to_translate, to_language="auto"):
    bahasa_awal = "auto"
    bahasa_tujuan = to_language
    kata = to_translate
    url = 'https://translate.google.com/m?sl=%s&tl=%s&ie=UTF-8&prev=_m&q=%s' % (bahasa_awal, bahasa_tujuan, kata.replace(" ", "+"))
    agent = {'User-Agent':random.choice(settings["userAgent"])}
    cari_hasil = 'class="t0">'
    request = urllib.parse.Request(url, headers=agent)
    page = urllib.parse.urlopen(request).read()
    result = page[page.find(cari_hasil)+len(cari_hasil):]
    result = result.split("<")[0]
    return result
#==============================================================================================================
def sendMention(to, mid, firstmessage, lastmessage):
    try:
        arrData = ""
        text = "%s " %(str(firstmessage))
        arr = []
        mention = "@x "
        slen = str(len(text))
        elen = str(len(text) + len(mention) - 1)
        arrData = {'S':slen, 'E':elen, 'M':mid}
        arr.append(arrData)
        text += mention + str(lastmessage)
        client.sendMessage(to, text, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        logError(error)
        client.sendMessage(to, "[ INFO ] Error :\n" + str(error)) 
#==============================================================================================================
def dhil(to, mid):
    try:
        arrData = ""
        textx = "╔══════════════\n╠ "
        arr = []
        no = 1
        for i in mid:
            mention = "@x\n"
            slen = str(len(textx))
            elen = str(len(textx) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':i}
            arr.append(arrData)
            textx += mention
            if int(no) < int(len(mid)):
                no += 1
                textx += "╠ "
            else:
                textx += "╚══════════════"
        client.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        logError(error)
        client.sendMessage(to, "[ INFO ] Error :\n" + str(error))
#=========================================================================================
def yt(query):
    with requests.session() as s:
         isi = []
         if query == "":
             query = "S1B tanysyz"
         s.headers['user-agent'] = 'Mozilla/5.0'
         url = 'http://www.youtube.com/results'
         params = {'search_query': query}
         r = s.get(url, params=params)
         soup = BeautifulSoup(r.content, 'html5lib')
         for a in soup.select('.yt-lockup-title > a[title]'):
            if '&list=' not in a['href']:
                if 'watch?v' in a['href']:
                    b = a['href'].replace('watch?v=', '')
                    isi += ['youtu.be' + b]
         return isi
#==============================================================================================================
def command(text):
    pesan = text.lower()
    if pesan.startswith(settings["keyCommand"]):
        cmd = pesan.replace(settings["keyCommand"],"")
    else:
        cmd = "Undefined command"
    return cmd
#==============================================================================================================
def help():
    key = settings["keyCommand"]
    key = key.title()
    helpMessage = "╔════[ Selfbots Commands ]" + "\n" + \
                  "╠ Your key => [" + key + "] " + "\n" + \
                  "╠ " + key + "Me" + "\n" + \
                  "╠ " + key + "Time" + "\n" + \
                  "╠ " + key + "Reboot" + "\n" + \
                  "╠ " + key + "Speed" + "\n" + \
                  "╠ " + key + "Gift" + "\n" + \
                  "╠ " + key + "Gurl" + "\n" + \
                  "╠ " + key + "My pp" + "\n" + \
                  "╠ " + key + "My cover" + "\n" + \
                  "╠ " + key + "My bio" + "\n" + \
                  "╠ " + key + "Close" + "\n" + \
                  "╠ " + key + "Leave" + "\n" + \
                  "╠ " + key + "Mid 「@」" + "\n" + \
                  "╠ " + key + "Sc 「@」" + "\n" + \
                  "╠ " + key + "Kick 「@」" + "\n" + \
                  "╠ " + key + "Getpp 「@」" + "\n" + \
                  "╠ " + key + "Getcover 「@」" + "\n" + \
                  "╠ " + key + "Getbio 「@」" + "\n" + \
                  "╠ " + key + "Getid 「@」" + "\n" + \
                  "╠ " + key + "Clone 「@」" + "\n" + \
                  "╠ " + key + "Profile 「@」" + "\n" + \
                  "╠ " + key + "Update pict" + "\n" + \
                  "╠ " + key + "Update icon" + "\n" + \
                  "╠ " + key + "Gn 「text」" + "\n" + \
                  "╠ " + key + "Ats" + "\n" + \
                  "╠ " + key + "Pict group" + "\n" + \
                  "╠ " + key + "Gcast 「text」" + "\n" + \
                  "╠ " + key + "Pmcast 「text」" + "\n" + \
                  "╠ " + key + "Broadcasted 「text」" + "\n" + \
                  "╠ " + key + "Grouplist" + "\n" + \
                  "╠ " + key + "Memberlist" + "\n" + \
                  "╠ " + key + "Reject" + "\n" + \
                  "╠ " + key + "Cancel" + "\n" + \
                  "╠ " + key + "Back" + "\n" + \
                  "╠ " + key + "Invgcall 「Jumlah」" + "\n" + \
                  "╠ " + key + "Removechat" + "\n" + \
                  "╠ " + key + "Changekey 「new key」" + "\n" + \
                  "╠ " + key + "Runtime" + "\n" + \
                  "╠ " + key + "Liststicker" + "\n" + \
                  "╠ " + key + "Spamsticker 「Numb」 「key sticker」" + "\n" + \
                  "╠ " + key + "Spam 「On」 「Numb」 「Text」" + "\n" + \
                  "╠ " + key + "Spamtag 「Numb」 「@」" + "\n" + \
                  "╠ " + key + "Spamgift 「Numb」 「@」" + "\n" + \
                  "╚═══════════════════\n" + \
                  "╔═══════════════════\n" + \
                  "╠ " + key + "Welcomemsg on" + "\n" + \
                  "╠ " + key + "Welcomemsg off" + "\n" + \
                  "╠ " + key + "Cctv on" + "\n" + \
                  "╠ " + key + "Cctv off" + "\n" + \
                  "╠ " + key + "Cctv reset" + "\n" + \
                  "╠ " + key + "Cctv result" + "\n" + \
                  "╠════ [CCTV BY TAG] " + "\n" + \
                  "╠ " + key + "Lurk on" + "\n" + \
                  "╠ " + key + "Lurk off" + "\n" + \
                  "╠ " + key + "Reset" + "\n" + \
                  "╠ " + key + "Lurkers" + "\n" + \
                  "╚═══════════════════\n" + \
                  "╔═══════════════════\n" + \
                  "╠ " + key + "Autoread on" + "\n" + \
                  "╠ " + key + "Autoread off" + "\n" + \
                  "╠ " + key + "Ceksider:on" + "\n" + \
                  "╠ " + key + "Ceksider:off" + "\n" + \
                  "╚═══════════════════\n" + \
                  "╔═══════════════════\n" + \
                  "╠ " + key + "Image 「query」" + "\n" + \
                  "╠ " + key + "Music 「query」" + "\n" + \
                  "╠ " + key + "Lyric 「query」" + "\n" + \
                  "╠ " + key + "Mp3 「query」" + "\n" + \
                  "╠ " + key + "Mp4 「query」" + "\n" + \
                  "╠ " + key + "Youtube 「query」" + "\n" + \
                  "╠ " + key + "Waktusalat 「Location」" + "\n" + \
                  "╠ " + key + "Cuaca 「Location」" + "\n" + \
                  "╠ " + key + "Lokasi 「Location」" + "\n" + \
                  "╚═══════════════════\n" + \
                  "╔═══════════════════\n" + \
                  "╠ " + key + "Namelock on" + "\n" + \
                  "╠ " + key + "Namelock off" + "\n" + \
                  "╠ " + key + "Qr on" + "\n" + \
                  "╠ " + key + "Qr off" + "\n" + \
                  "╠ " + key + "Invite on" + "\n" + \
                  "╠ " + key + "Invite off" + "\n" + \
                  "╚═══════════════════\n" + \
                  "╔═══════[ My Team ]" + "\n" + \
                  "╠ " + key + "✍PRΩLIΠG TΣΔM βΩT" + "\n" + \
                  "╠ " + key + "🔫ˢᴵᴸᴱᴺᵀReadeR🔫" + "\n" + \
                  "╠ " + key + "̙̙͟͢͞Y҉̙̙̙͆̐͘͢͞K҉̙̙̙͍͍̱̬̋̿̐͢͞M҉̙̙̙ͪͪ͢͞ᴵ͍͍̩͍֞͌֞L҉̙̙̙ͯͯͯ͢" + "\n" + \
                  "╚═══════════════════"
                  
    return helpMessage
#==============================================================================================================
def backupData():
    try:
        backup = settings
        f = codecs.open('temp.json','w','utf-8')
        json.dump(backup, f, sort_keys=True, indent=4, ensure_ascii=False)
        backup = read
        f = codecs.open('read.json','w','utf-8')
        json.dump(backup, f, sort_keys=True, indent=4, ensure_ascii=False)
        return True
    except Exception as error:
        logError(error)
        return False   
#========================================================================
#===================================================================================
def cms(string, commands): #/XXX, >XXX, ;XXX, ^XXX, %XXX, $XXX...
    tex = ["+","@","/",">",";","^","%","$","＾","サテラ:","サテラ:","サテラ：","サテラ："]
    for texX in tex:
        for command in commands:
            if string ==command:
                return True
    return False
#============================================================================================
#==============================================================================================================
def clientBot(op):
    try:
        if op.type == 0:
            return
#========================================================================
#============================================================================================
#==============================================================================================================
#        if op.type == 5:
#            print ("[ 5 ] NOTIFIED ADD CONTACT")
#            if settings["autoAdd"] == True:
#               client.findAndAddContactsByMid(op.param1)
#          client.sendMessage(op.param1, "Halo {}\nterimakasih telah menambahkan saya sebagai teman".format(str(client.getContact(op.param1).displayName)))
        if op.type == 5:
            print ("[5] NOTIFIED ADD CONTACT")
            if settings["autoAdd"] == True:
                sendMention(op.param1, op.param1, "Thank's for add me", "\nMy selfbot By: http://line.me/ti/p/veO06X5hl3")
                client.sendMessage(op.param1, text=None, contentMetadata={'mid':"ue7fcc891e44845b029f17e34353a971a"}, contentType=13)
                arg = "   New Friend : {}".format(str(client.getContact(op.param1).displayName))
                print (arg)
#========================================================================
#============================================================================================
#==============================================================================================================
        if op.type == 11:
            print ("[ 11 ] NOTIFIED UPDATE GROUP")
            if op.param3 == "1":
                group = client.getGroup(op.param1)
                contact = client.getContact(op.param2)
                arg = "   Changed : Group Name"
                arg += "\n   New Group Name : {}".format(str(group.name))
                arg += "\n   Executor : {}".format(str(contact.displayName))
                print (arg)
            elif op.param3 == "4":
                group = client.getGroup(op.param1)
                contact = client.getContact(op.param2)
                if group.preventedJoinByTicket == False:
                    gQr = "Opened"
                else:
                    gQr = "Closed"
                arg = "   Changed : Group Qr"
                arg += "\n   Group Name : {}".format(str(group.name))
                arg += "\n   New Group Qr Status : {}".format(gQr)
                arg += "\n   Executor : {}".format(str(contact.displayName))
                print (arg)
#========================================================================              
        if op.type == 11:
            if op.param3 == '1':
                if op.param1 in settings['pname']:
                    try:
                        G = client.getGroup(op.param1)
                    except:
                        try:
                            G = client2.getGroup(op.param1)
                        except:
                            try:
                                G = client3.getGroup(op.param1)
                            except:
                                try:
                                    G = client4.getGroup(op.param1)
                                except:
                                    try:
                                        G = client5.getGroup(op.param1)
                                    except:
                                        try:
                                            G = client6.getGroup(op.param1)
                                        except:
                                            pass
                    G.name = settings['pro_name'][op.param1]
                    try:
                        client.updateGroup(G)
                    except:
                        try:
                            client2.updateGroup(G)
                        except:
                            try:
                                client3.updateGroup(G)
                            except:
                                try:
                                    client4.updateGroup(G)
                                except:
                                    try:
                                        client5.updateGroup(G)
                                    except:
                                        try:
                                            client6.updateGroup(G)
                                        except:
                                            pass
                    if op.param2 in ken:
                        pass
                    else:
                        try:
                            client2.kickoutFromGroup(op.param1,[op.param2])
                        except:
                            try:
                                client3.kickoutFromGroup(op.param1,[op.param2])
                            except:
                                try:
                                    client4.kickoutFromGroup(op.param1,[op.param2])
                                except:
                                    try:
                                        client5.kickoutFromGroup(op.param1,[op.param2])
                                    except:
                                        try:
                                            client6.kickoutFromGroup(op.param1,[op.param2])
                                        except:
                                            pass
#=================================================================================                
        if op.type == 11:
           if settings["linkprotect"] == True:
               #if op.param2 not in Bots:
                   G = client.getGroup(op.param1)
                   G.preventedJoinByTicket = True
                   #random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                   client.updateGroup(G)
#==========================================================================        
        if op.type == 13:
           if settings["inviteprotect"] == True:
               #if op.param2 not in Bots:
                  client.cancelGroupInvitation(op.param1,[op.param3])
                  #ki3.kickoutFromGroup(op.param1,[op.param2])                  
#================================================================================
        if op.type == 19:
            if settings["Mprotection"] == True:
               #if op.param2 not in Bots and admin:
                  #ki.kickoutFromGroup(op.param1,[op.param2]) 
                  client.findAndAddContactsByMid(op.param1,[op.param3])
                  client.inviteIntoGroup(op.param1,[op.param3])
#               if op.param2 in settings["blacklist"]:
#     	            pass
               #if op.param2 in wait["whitelist"]:
                   #pass
#               else:
#                   settings["blacklist"][op.param2] = True
#============================================================================================
#==============================================================================================================
        if op.type == 13:
            print ("[ 13 ] NOTIFIED INVITE INTO GROUP")
            group = client.getGroup(op.param1)
            contact = client.getContact(op.param2)
            if settings["autoJoin"] == True:
                if settings["autoReject"]["status"] == True:
                    if len(group.members) > settings["autoReject"]["members"]:
                        client.acceptGroupInvitation(op.param1)
                    else:
                        client.acceptGroupInvitation(op.param1)
                        client.sendMessage(op.param1, "Sorry {}\nYou are not my Author, I leave!".format(str(client.getContact(op.param2).displayName)))
                        client.sendMessage(op.param1, text=None, contentMetadata={'mid': op.param2}, contentType=13)
                        client.leaveGroup(op.param1)
                else:
                    client.acceptGroupInvitation(op.param1)
            gInviMids = []
            for z in group.invitee:
                if z.mid in op.param3:
                    gInviMids.append(z.mid)
            listContact = ""
            if gInviMids != []:
                for j in gInviMids:
                    name_ = client.getContact(j).displayName
                    listContact += "\n      + {}".format(str(name_))
            arg = "   Group Name : {}".format(str(group.name))
            arg += "\n   Executor : {}".format(str(contact.displayName))
            arg += "\n   List User Invited : {}".format(str(listContact))
            print (arg)
#========================================================================
#============================================================================================
#==============================================================================================================
        if op.type == 17:
            print ("[ 17 ]  NOTIFIED ACCEPT GROUP INVITATION")
            group = client.getGroup(op.param1)
            contact = client.getContact(op.param2)
            arg = "   Group Name : {}".format(str(group.name))
            arg += "\n   User Join : {}".format(str(contact.displayName))
            print (arg)                    
#========================================================================
#============================================================================================
#==============================================================================================================
        if op.type == 19:
            print ("[ 19 ] NOTIFIED KICKOUT FROM GROUP")
            group = client.getGroup(op.param1)
            contact = client.getContact(op.param2)
            victim = client.getContact(op.param3)
            arg = "   Group Name : {}".format(str(group.name))
            arg += "\n   Executor : {}".format(str(contact.displayName))
            arg += "\n   Victim : {}".format(str(victim.displayName))
            print (arg)
#========================================================================
#============================================================================================
#==============================================================================================================
        if op.type == 22:
            print ("[ 22 ] NOTIFIED INVITE INTO ROOM")
            if settings["autoLeave"] == True:
                client.sendMessage(op.param1, "")
                client.leaveRoom(op.param1)
#========================================================================
#============================================================================================
#==============================================================================================================
        if op.type == 24:
            print ("[ 24 ] NOTIFIED LEAVE ROOM")
            if settings["autoLeave"] == True:
                client.sendMessage(op.param1, "")
                client.leaveRoom(op.param1)
#========================================================================
#============================================================================================
#========================================================================
        if op.type == 25:
            print ("[ 25 ] SEND MESSAGE")
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            # Check if in group chat or personal chat
            if msg.toType == 0 or msg.toType == 2:
                if msg.toType == 0:
                    to = receiver
                elif msg.toType == 2:
                    to = receiver
                # Check if only text message
                if msg.contentType == 0:
                    if settings["autoRead"] == True:
                        client.sendChatChecked(to, msg_id)
                    if text is None:
                        return
                    else:
                        cmd = command(text)
                    if cmd != "Undefined command":
                        # Basic command                               
#=========================================================================================                        
#=========================================================================================
#========================================================================
                        if cmd == "help" or cmd == "koran":
                            helpMessage = help()
                            client.sendMessage(to, str(helpMessage))
#========================================================================
                        elif cmd == "me":
                            contact = client.getProfile().displayName
                            sendMention(to, msg._from, "","")    
                            client.sendContact(to, sender)
#========================================================================
                        elif cmd == 'mid':
                            client.sendMessage(msg.to,"「My mid」\n" +  clientMID)
                            print ("[COMMAND] MID")    
#========================================================================   
                        elif cmd == 'my name':
                            me = client.getContact(clientMID)
                            client.sendMessage(msg.to,"「Display my name」\n" + me.displayName)
                            print ("[COMMAND] DISPLAY NAME")
#========================================================================          
                        elif cmd == 'my bio':
                            me = client.getContact(clientMID)
                            client.sendMessage(msg.to,"「Status」\n" + me.statusMessage)
                            print ("[COMMAND] MY BIO")
#========================================================================          
                        elif cmd == 'my pp':
                            me = client.getContact(clientMID)
                            client.sendImageWithURL(msg.to,"http://dl.profile.line-cdn.net/" + me.pictureStatus)
                            print ("[COMMAND] MY PICTURE")
#========================================================================          
                        elif cmd == 'my vp':
                            me = client.getContact(clientMID)
                            client.sendVideoWithURL(msg.to,"http://dl.profile.line-cdn.net/" + me.pictureStatus + "/vp")
#========================================================================       
                        elif cmd == 'my cover':
                            me = client.getContact(clientMID)
                            cover = channel.getProfileCoverURL(clientMID)    
                            client.sendImageWithURL(msg.to, cover)
                            print ("[COMMAND] MY COVER")
#========================================================================            
                        elif ("Gn " in msg.text):
                            X = client.getGroup(msg.to)
                            X.name = msg.text.replace("Gn ","")
                            client.updateGroup(X)
                            print ("[COMMAND] GNAME")
#========================================================================                    
                        elif "sc" in msg.text.lower():
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    contact = client.getContact(ls)
                                    mi_d = contact.mid
                                    client.sendContact(msg.to, mi_d)           
#========================================================================                            
                        elif "clone" in msg.text.lower():
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                for mention in mentionees:
                                    contact = mention["M"]
                                    break
                                try:
                                    client.cloneContactProfile(contact)
                                    client.sendMessage(msg.to, "「Clone sucses」")
                                except:
                                    client.sendMessage(msg.to, "「Clone failed」")
                                    print ("[COMMAND] COPY OK")
#========================================================================                                    
                        elif text.lower() == 'back':
                            try:
                                clientProfile.displayName = str(myProfile["displayName"])
                                clientProfile.statusMessage = str(myProfile["statusMessage"])
                                clientProfile.pictureStatus = str(myProfile["pictureStatus"])
                                client.updateProfileAttribute(8, clientProfile.pictureStatus)
                                client.updateProfile(clientProfile)
                                client.sendMessage(msg.to, "「Backup my profile sucses」")
                            except:
                                client.sendMessage(msg.to, "「Backup my profile failed」")
                                print ("[COMMAND] BACKUP OK")                        
#============================================================================================            
                        elif cmd == "restart" or cmd == "reboot":
                            client.sendMessage(to, "「Restarted your Bots Programs」")
                            settings["restartPoint"] = to
                            restartBot()
#========================================================================
                        elif cmd == "runtime":
                            timeNow = time.time()
                            runtime = timeNow - botStart
                            runtime = format_timespan(runtime)
                            resetTime = timeNow - int(settings["timeRestart"])
                            resetTime = format_timespan(resetTime)
                            client.sendMessage(to, "Running time「{}」".format(str(runtime), str(resetTime)))
#========================================================================
                        elif cmd == "removechat":
                            client.removeAllMessages(op.param2)
                            client.sendMessage(to, "「Done clear all chat」")
#========================================================================
                        elif cmd == "speed" or cmd == "sp":
                            start = time.time()
                            client.sendMessage(to,"Progress..")
                            elapsed_time = time.time() - start
                            client.sendMessage(to, "{} Second".format(str(elapsed_time)))
#======================================================================== # AUTO JOIN QR
                        elif "/ti/g/" in msg.text.lower():
                            if settings["autoJoinTicket"] == True:
                                link_re = re.compile('(?:line\:\/|line\.me\/R)\/ti\/g\/([a-zA-Z0-9_-]+)?')
                                links = link_re.findall(text)
                                n_links = []
                                for l in links:
                                    if l not in n_links:
                                        n_links.append(l)
                                for ticket_id in n_links:
                                    group = client.findGroupByTicket(ticket_id)
                                    client.acceptGroupInvitationByTicket(group.id,ticket_id)
                                    client.sendMessage(to, "Succes join to group %s" % str(group.name))
#========================================================================
                        elif cmd.startswith("gcancel "):                                                        
                            try:
                                strnum = text.replace("gcancel ","")
                                if strnum == "off":
                                    settings["autoReject"]["status"] = False
                                    if settings["server"] == "VPS":
                                        client.sendMessage(to,"Group cancel OFF!")
                                    else:
                                        client.sendMessage(to,"Group cancel OFF!")
                                else:
                                    num = int(strnum)
                                    settings["autoReject"]["status"] = True
                                    settings["autoReject"]["members"]
                                    if settings["server"] == "VPS":
                                        client.sendMessage(to,strnum + "Done")
                                    else:
                                        client.sendMessage(to,strnum + "Done")
                            except:
                                if settings["server"] == "VPS":
                                    client.sendMessage(to,"Wrong count!!")
                                else:
                                    client.sendMessage(to,"Weird value")
                        elif cmd == "leave":
                            if msg.toType == 2:
                                client.leaveGroup(to)
#========================================================================
                        elif cmd == "time":
                            tz = pytz.timezone("Asia/Jakarta")
                            timeNow = datetime.now(tz=tz)
                            day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday", "Saturday"]
                            hari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"]
                            bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
                            hr = timeNow.strftime("%A")
                            bln = timeNow.strftime("%m")
                            for i in range(len(day)):
                                if hr == day[i]: hasil = hari[i]
                            for k in range(0, len(bulan)):
                                if bln == str(k): bln = bulan[k-1]
                            anu = hasil + ", " + timeNow.strftime('%d') + " - " + bln + " - " + timeNow.strftime('%Y') + "\nJam : [ " + timeNow.strftime('%H:%M:%S') + " ]"
                            client.sendMessage(to, anu)
#========================================================================
                        elif cmd.startswith("ats"):
                                group = client.getGroup(msg.to)
                                nama = [contact.mid for contact in group.members]
                                nm1, nm2, nm3, nm4, nm5, jml = [], [], [], [], [], len(nama)
                                if jml <= 100:
                                    dhil(msg.to, nama)
                                if jml > 100 and jml < 200:
                                    for i in range(0, 100):
                                        nm1 += [nama[i]]
                                    dhil(msg.to, nm1)
                                    for j in range(101, len(nama)):
                                        nm2 += [nama[j]]
                                    dhil(msg.to, nm2)
                                if jml > 200 and jml < 300:
                                    for i in range(0, 100):
                                        nm1 += [nama[i]]
                                    dhil(msg.to, nm1)
                                    for j in range(101, 200):
                                        nm2 += [nama[j]]
                                    dhil(msg.to, nm2)
                                    for k in range(201, len(nama)):
                                        nm3 += [nama[k]]
                                    dhil(msg.to, nm3)
                                if jml > 300 and jml < 400:
                                    for i in range(0, 100):
                                        nm1 += [nama[i]]
                                    dhil(msg.to, nm1)
                                    for j in range(101, 200):
                                        nm2 += [nama[j]]
                                    dhil(msg.to, nm2)
                                    for k in range(201, len(nama)):
                                        nm3 += [nama[k]]
                                    dhil(msg.to, nm3)
                                    for l in range(301, len(nama)):
                                        nm4 += [nama[l]]
                                    dhil(msg.to, nm4)
                                if jml > 400 and jml < 501:
                                    for i in range(0, 100):
                                        nm1 += [nama[i]]
                                    dhil(msg.to, nm1)
                                    for j in range(101, 200):
                                        nm2 += [nama[j]]
                                    dhil(msg.to, nm2)
                                    for k in range(201, len(nama)):
                                        nm3 += [nama[k]]
                                    dhil(msg.to, nm3)
                                    for l in range(301, len(nama)):
                                        nm4 += [nama[l]]
                                    dhil(msg.to, nm4)
                                    for m in range(401, len(nama)):
                                        nm5 += [nama[m]]
                                    dhil(msg.to, nm5)             
                                client.sendMessage(receiver, "Done: "+str(jml) + " Members")                                                     
#======================================================================== # CANCEL MEMBER
                        elif cmd == "cancel":
                            if msg.toType == 2:
                                group = client.getGroup(to)
                                if group.invitee is None:
                                    client.sendMessage(to, "Ga ada pendingan kak..")
                                else:
                                    gInviMids = [contact.mid for contact in group.invitee]
                                    client.cancelGroupInvitation(msg.to, gInviMids)
                                    client.sendMessage(to, str(len(group.invitee)) + " 「Done」")
                        elif text.lower() == "clear":
                            if msg.toType == 2:
                                group = client.getGroup(to)
                                if group.invitee is not None:
                                    gInviMids = [contact.mid for contact in group.invitee]
                                    client.cancelGroupInvitation(to, gInviMids)
#========================================================================                                    
                        elif text.lower() == 'gurl':
                            if msg.toType == 2:
                                x = client.getGroup(msg.to)
                                if x.preventedJoinByTicket == True:
                                    x.preventedJoinByTicket = False
                                    client.updateGroup(x)
                                gurl = client.reissueGroupTicket(msg.to)
                                client.sendMessage(msg.to,"line://ti/g/" + gurl)
#========================================================================
                        elif text.lower() == 'close':
                            if msg.toType == 2:
                                x = client.getGroup(msg.to)
                                if x.preventedJoinByTicket == False: 
                                    x.preventedJoinByTicket = True
                                    client.updateGroup(x)
                                    client.sendMessage(msg.to, "「UrL Group Invitation Refused」♪")                   
#======================================================================== # GROUP BROADCAST
                        elif cmd.startswith("gcast "):
                            sep = text.split(" ")
                            txt = text.replace(sep[0] + " ","")
                            groups = client.groups
                            for group in groups:
                                client.sendMessage(group, "{}".format(str(txt + "\n\nBroadcasted By: " + client.getContact(msg._from).displayName)))
                            #client.sendMessage(to, "Berhasil broadcast ke {} group".format(str(len(groups))))
#======================================================================== # FRIEND BROADCAST
                        elif cmd.startswith("pmcast "):
                            sep = text.split(" ")
                            txt = text.replace(sep[0] + " ","")
                            friends = client.friends
                            for friend in friends:
                                client.sendMessage(friend, "{}".format(str(txt + "\n\nBroadcasted By: " + client.getContact(msg._from).displayName)))
                            #client.sendMessage(to, "Berhasil broadcast ke {} teman".format(str(len(friends))))
#=======================================================================
                        elif cmd == "tag":
                            profile = client.getContact(msg.to)
                            sendMention(msg.to, msg.to, "Hi", "Check pc -,-")
#=======================================================================
                        elif cmd == "mic:":
                            mmid = text.replace("mic:","")                                
                            client.sendMessage(to, text=None, contentMetadata={'mid': mmid}, contentType=13)
#======================================================================== # GF BROADCAST
                        elif cmd.startswith("broadcasted "):
                            sep = text.split(" ")
                            txt = text.replace(sep[0] + " ","")
                            friends = client.friends
                            groups = client.groups
                            for group in groups:
                                client.sendMessage(group, "[ Broadcast ]\n{}".format(str(txt)))
                            client.sendMessage(to, "Berhasil broadcast ke {} group".format(str(len(groups))))
                            for friend in friends:
                                client.sendMessage(friend, "[ Broadcast ]\n{}".format(str(txt)))
                            client.sendMessage(to, "Berhasil broadcast ke {} teman".format(str(len(friends))))
#======================================================================== # GROUP LIST
                        elif cmd == "grouplist":
                            groups = client.groups
                            ret_ = "╔══[ Group List ]"
                            no = 1
                            for gid in groups:
                                group = client.getGroup(gid)
                                ret_ += "\n╠ {}. {} | {}".format(str(no), str(group.name), str(len(group.members)))
                                no = (no+1)
                            ret_ += "\n╚══[ Total {} Groups ]".format(str(len(groups)))
                            client.sendMessage(to, str(ret_))
#==========================================================================================
                        elif msg.text.lower() == 'memberlist':
                            kontak = client.getGroup(to)
                            group = kontak.members
                            num=1
                            msgs="════List Member════"
                            for ids in group:
                                msgs+="\n[%i] %s" % (num, ids.displayName)
                                num=(num+1)
                            msgs+="\n════List Member════\n\nTotal Members : %i" % len(group)
                            client.sendMessage(msg.to, msgs)
#==========================================================================================                        
                        elif cmd == "ginfo":
                                    group = client.getGroup(to)
                                    gCreator = group.creator.mid
                                    try:
                                        gCreator1 = group.creator.displayName
                                    except:
                                        gCreator = "Not Found"
                                    if group.invitee is None:
                                        gPending = "0"
                                    else:
                                        gPending = str(len(group.invitee))
                                    if group.preventedJoinByTicket == True:
                                        gQr = "Refused"
                                        gTicket = "Nothing"
                                    else:
                                        gQr = "Open"
                                        gTicket = "https://line.me/R/ti/g/{}".format(str(cl.reissueGroupTicket(group.id)))
                                    ret_ = "╔════════Grup Info═════════"
                                    ret_ += "\n╠Name Group : {}".format(group.name)
                                    ret_ += "\n╠ID Group : {}".format(group.id)
                                    ret_ += "\n╠Pic Group : http://dl.profile.line-cdn.net/" + str(group.pictureStatus)
                                    ret_ += "\n╠Group Creators  : {}".format(gCreator1)
                                    ret_ += "\n╠Group Members   : {}".format(str(len(group.members)))
                                    ret_ += "\n╠Pending Members : {}".format(gPending)
                                    ret_ += "\n╠Group QR        : {}".format(gQr)
                                    ret_ += "\n╠Group URL       : {}".format(gTicket)
                                    ret_ += "\n╚════════Grup Info═════════"
                                    client.sendMessage(to, str(ret_))
                                    client.sendImageWithURL(to, "http://dl.profile.line-cdn.net/"+str(group.pictureStatus))
                                    client.sendMessage(to, text=None, contentMetadata={'mid': gCreator}, contentType=13)
                                    sendMention(to, gCreator, "Hello", "Salken ya Kak Owner ^_^")        
#==============================================
#======================================================================== # DENY INVITES
                        elif cmd == "rejectall":
                            ginvited = client.ginvited
                            if ginvited != [] and ginvited != None:
                                for gid in ginvited:
                                    client.rejectGroupInvitation(gid)
                                client.sendMessage(to, "Succes reject {} Group invitation".format(str(len(ginvited))))
                            else:
                                client.sendMessage(to, "Tidak ada undangan yang tertunda")
#========================================================================
                        elif text.lower() == "mykey":
                            client.sendMessage(to, "Your key is\n=> {} <=".format(str(settings["keyCommand"])))
#========================================================================
                        elif cmd.startswith("changekey "):
                            sep = text.split(" ")
                            key = text.replace(sep[0] + " ","")
                            if " " in key:
                                client.sendMessage(to, "Key tidak bisa menggunakan spasi")
                            else:
                                settings["keyCommand"] = str(key).lower()
                                client.sendMessage(to, "Berhasil mengganti key menjadi {}".format(str(key).lower()))
#========================================================================
#============================================================================================
                        elif cmd == "set" or cmd == "settings":
                            md = "   ⛊ Status Settings Bots ⛊\n\n"
                            if settings["linkprotect"] == True: md+="✍Protect Link ✔\n"
                            else: md+="✍Protect Link✖\n"
                            if settings["inviteprotect"] == True: md+="✍Protect Invite ✔\n"
                            else: md+="✍Protect Invite✖\n"
                            if settings["pname"] == True: md+="✍Namelock ✔\n"
                            else: md+="✍Namelock✖\n"
                            if settings["contact"] == True: md+="✍Contact ✔\n"
                            else: md+="✍Contact✖\n"
                            if settings["notag"] == True: md+="✍Notag ✔\n"
                            else: md+="✍Notag✖\n" 
                            if settings["autotag"] == True: md+="✍Auto Respon Tag ✔\n"
                            else: md+="✍Auto Respon Tag✖\n" 
                            if settings["responpm"] == True: md+="✍Auto Respon Pm ✔\n"
                            else: md+="✍Auto Respon Pm✖\n" 
                            if settings["autoJoin"] == True: md+="✍Auto join ✔\n" 
                            else: md+="✍Auto join✖\n" 
                            if settings["welcome"] == True: md+="✍Welcome message ✔\n" 
                            else: md +="✍Welcome message✖\n"
                            if settings["autoRead"] == True: md+="✍Auto Read ✔\n" 
                            else: md +="✍Auto Read✖\n"   
                            if settings["autoAdd"] == True: md+="✍Auto add ✔\n\n ⏩✍PRΩLIΠG TΣΔM βΩT⏪"    
                            else:md+="✍Auto add✖\n\n ⏩✍PRΩLIΠG TΣΔM βΩT⏪"     
                            client.sendMessage(to, md + "\n\n" +datetime.today().strftime('🗓 Date : %d-%b-%Y\n⌚ Time : %H:%M:%S %P') )     
                            client.sendMessage(to, text=None, contentMetadata = {'mid': "ue7fcc891e44845b029f17e34353a971a"}, contentType=13)       
#==============================================================================================================
#           ||===========|| KICKING COMMANDS ||===========||
#========================================================================
#========================================================================
                        elif cmd == "gift":
                            client.sendMessage(to, text=None, contentMetadata=None, contentType=9)    
#============================================================================================
                        elif cmd == "reject":
                            gid = client.getGroupIdsInvited()
                            for i in gid:
                                client.rejectGroupInvitation(i)
                                client.sendMessage(to,"「Desclined all group invitations」")
                            else:
                                client.sendMessage(to,"")
#==============================================================================================================
                        elif cmd.startswith("kick "):
                            if 'MENTION' in msg.contentMetadata.keys() != None:
                                names = re.findall(r'@(\w+)', msg.text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                for mention in mentionees:
                                    try:                                    
                                        client.kickoutFromGroup(msg.to, [mention['M']])
                                    except:
                                        try:
                                            client.kickoutFromGroup(msg.to, [mention['M']])
                                        except:
                                            try:
                                                client.kickoutFromGroup(msg.to, [mention['M']])
                                            except:
                                                client.sendMessage(msg.to, "Error")
#========================================================================
#==========================================================================================
                        elif cmd == "ban all":
                            if msg.toType == 2:
                                print ("[NB]ok")
                                _name = text.replace("ban all","")
                                gs = client.getGroup(to)
                                targets = []
                                for g in gs.members:
                                    if _name in g.displayName:
                                       targets.append(g.mid)
                                if targets == []:
                                    client.sendMessage(to,"Not found.")
                                else:
                                    for target in targets:
                                        try:
                                            settings["blacklist"][target] = True
                                            f=codecs.open('st2__b.json','w','utf-8')
                                            json.dump(settings["blacklist"], f, sort_keys=True, indent=4,ensure_ascii=False)
                                            client.sendMessage(to,"「Target Locked」")
                                        except:
                                            cl.sendMessage(to,"Error")
#==========================================================================================
                        elif cmd.startswith("B "):                
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                   targets.append(x["M"])
                               for target in targets:
                                   try:
                                       settings["blacklist"][target] = True
                                       f=codecs.open('st2__b.json','w','utf-8')
                                       json.dump(settings["blacklist"], f, sort_keys=True, indent=4,ensure_ascii=False)
                                       client.sendMessage(to,"「Target Locked」")
                                       print ("[Command] Banned")
                                   except:
                                       pass
#==========================================================================================
                        elif cmd.startswith("W "):
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                   targets.append(x["M"])
                               for target in targets:
                                   try:
                                       del settings["blacklist"][target]
                                       f=codecs.open('st2__b.json','w','utf-8')
                                       json.dump(settings["blacklist"], f, sort_keys=True, indent=4,ensure_ascii=False)
                                       client.sendMessage(msg.to,"「Target Unlocked」")
                                       print ("[Command] Unbanned")
                                   except:
                                       pass                                        
#============================================================================================
#==============================================================================================================
#           ||===========|| STEALIG COMMANDS ||===========||
#========================================================================
#============================================================================================
#==============================================================================================================
#============================================================================================                                        
                        elif 'getpp' in text.lower():
                            try:
                                key = eval(msg.contentMetadata["MENTION"])
                                u = key["MENTIONEES"][0]["M"]
                                a = client.getContact(u).pictureStatus
                                if "videoProfile='{" in str(client.getContact(u)):
                                    client.sendVideoWithURL(receiver, 'http://dl.profile.line.naver.jp/'+a+'/vp.small')
                                else:
                                    client.sendImageWithURL(receiver, 'http://dl.profile.line.naver.jp/'+a)
                            except Exception as e:
                                client.sendMessage(receiver, str(e))                                                          
#========================================================================
                        elif cmd.startswith("getcover "):
                            if channel != None:
                                if 'MENTION' in msg.contentMetadata.keys()!= None:
                                    names = re.findall(r'@(\w+)', text)
                                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                    mentionees = mention['MENTIONEES']
                                    lists = []
                                    for mention in mentionees:
                                        if mention["M"] not in lists:
                                            lists.append(mention["M"])
                                    for ls in lists:
                                        path = channel.getProfileCoverURL(ls)                        
                                        path = str(path)
                                        if settings["server"] == "VPS":
                                            client.sendImageWithURL(to, str(path))
                                        else:
                                            urllib.urlretrieve(path, "steal.jpg")
                                            client.sendImage(to, "steal.jpg")
                            else:
                                client.sendMessage(to, "Tidak dapat masuk di line channel")
#========================================================================
                        elif cmd.startswith("profile "):
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    if 'displayName' in msg.contentMetadata:
                                        contact = client.getContact(ls)                                        
                                        try:                                            
                                            cu = channel.getProfileCoverURL(ls)
                                        except:
                                            cu = ""                                            
                                        client.sendMessage(msg.to,"「DisplayName」:\n" + contact.displayName + "\n[mid]:\n" + msg.contentMetadata["mid"] + "\n[statusMessage]:\n" + contact.statusMessage + "\n[pictureStatus]:\nhttp://dl.profile.line-cdn.net/" + contact.pictureStatus + "\n[coverURL]:\n" + str(cu))
                                    else:
                                        contact = client.getContact(ls)
                                        try:
                                            cu = channel.getProfileCoverURL(ls)
                                        except:
                                            cu = ""                                                                                                                   
                                    if settings["server"] == "VPS":
                                        client.sendMessage(to,"「DisplayName」:\n" + contact.displayName + "\n\n[statusMessage]:\n" + contact.statusMessage)
                                        client.sendMessage(to,"「Profile Picture」")
                                        client.sendImageWithURL(to,"http://dl.profile.line-cdn.net/" + contact.pictureStatus)
                                        client.sendMessage(to, "「Cover」")
                                        client.sendImageWithURL(to, str(cu))
                                        #client.sendMessage(to, text=None, contenMetadata={'mid': mid(ls)}, contentType=13)
                                        client.sendMessage(to, "「Done」")
                                        #urllib.urlretrieve(cu, "steal.jpg")
                                        #client.sendImage(to, "steal.jpg")
#========================================================================
                        elif cmd.startswith("getid "):
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    if 'displayName' in msg.contentMetadata:
                                        contact = client.getContact(ls)
                                        try:                                            
                                            cu = channel.getProfileCoverURL(ls)
                                        except:
                                            cu = ""                                            
                                        client.sendMessage(msg.to,"「DisplayName」:\n" + contact.displayName + "\n[mid]:\n" + msg.contentMetadata["mid"] + "\n[statusMessage]:\n" + contact.statusMessage + "\n[pictureStatus]:\nhttp://dl.profile.line-cdn.net/" + contact.pictureStatus + "\n[coverURL]:\n" + str(cu))
                                    else:
                                        contact = client.getContact(ls)
                                        try:
                                            cu = channel.getProfileCoverURL(ls)
                                        except:
                                            cu = ""
                                    if settings["server"] == "VPS":
                                        client.sendMessage(msg.to,"「DisplayName」:\n" + contact.displayName + "\n[mid]:\n" + (str(contact.mid)) + "\n[statusMessage]:\n" + contact.statusMessage + "\n[pictureStatus]:\nhttp://dl.profile.line-cdn.net/" + contact.pictureStatus + "\n[coverURL]:\n" + str(cu))                                        
                                        client.sendImageWithURL(to,"http://dl.profile.line-cdn.net/" + contact.pictureStatus)                                        
                                        client.sendImageWithURL(to, str(cu))                                        
#========================================================================
                        elif cmd.startswith("getbio "):
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                for ls in lists:
                                    contact = client.getContact(ls)
                                    client.sendMessage(to, "[ Status Message ]\n{}".format(str(contact.statusMessage)))
#========================================================================
                        elif cmd.startswith("mid "):
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                names = re.findall(r'@(\w+)', text)
                                mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                mentionees = mention['MENTIONEES']
                                lists = []
                                for mention in mentionees:
                                    if mention["M"] not in lists:
                                        lists.append(mention["M"])
                                ret_ = ""
                                for ls in lists:
                                    ret_ += "{}".format(str(ls))
                                client.sendMessage(to, str(ret_))                        
#========================================================================
                        elif cmd == "pict group":
                            if msg.toType == 2:
                                group = client.getGroup(to)
                                path = "http://dl.profile.line-cdn.net/" + group.pictureStatus
                                if settings["server"] == "VPS":
                                    client.sendImageWithURL(to, str(path))
                                else:
                                    urllib.urlretrieve(path, "gpict.jpg")
                                    client.sendImage(to, "gpict.jpg")
#========================================================================
                        elif cmd == "lurk on":
                                tz = pytz.timezone("Asia/Jakarta")
                                timeNow = datetime.now(tz=tz)
                                day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday", "Saturday"]
                                hari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"]
                                bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
                                hr = timeNow.strftime("%A")
                                bln = timeNow.strftime("%m")
                                for i in range(len(day)):
                                    if hr == day[i]: hasil = hari[i]
                                for k in range(0, len(bulan)):
                                    if bln == str(k): bln = bulan[k-1]
                                readTime = hasil + ", " + timeNow.strftime('%d') + " - " + bln + " - " + timeNow.strftime('%Y') + "\nJam : [ " + timeNow.strftime('%H:%M:%S') + " ]"
                                if msg.to in read['readPoint']:
                                        try:
                                            del read['readPoint'][msg.to]
                                            del read['readMember'][msg.to]
                                            del read['readTime'][msg.to]
                                        except:
                                            pass
                                        read['readPoint'][msg.to] = msg.id
                                        read['readMember'][msg.to] = ""
                                        read['readTime'][msg.to] = datetime.now().strftime('%H:%M:%S')
                                        read['ROM'][msg.to] = {}
                                        with open('sider.json', 'w') as fp:
                                            json.dump(read, fp, sort_keys=True, indent=4)
                                            client.sendMessage(msg.to,"Lurking already on")
                                else:
                                    try:
                                        del read['readPoint'][msg.to]
                                        del read['readMember'][msg.to]
                                        del read['readTime'][msg.to]
                                    except:
                                        pass
                                    read['readPoint'][msg.to] = msg.id
                                    read['readMember'][msg.to] = ""
                                    read['readTime'][msg.to] = datetime.now().strftime('%H:%M:%S')
                                    read['ROM'][msg.to] = {}
                                    with open('sider.json', 'w') as fp:
                                        json.dump(read, fp, sort_keys=True, indent=4)
                                        client.sendMessage(msg.to, "Set reading point:\n" + readTime)
                                        
                        elif cmd == "lurk off":
                                tz = pytz.timezone("Asia/Jakarta")
                                timeNow = datetime.now(tz=tz)
                                day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday", "Saturday"]
                                hari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"]
                                bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
                                hr = timeNow.strftime("%A")
                                bln = timeNow.strftime("%m")
                                for i in range(len(day)):
                                    if hr == day[i]: hasil = hari[i]
                                for k in range(0, len(bulan)):
                                    if bln == str(k): bln = bulan[k-1]
                                readTime = hasil + ", " + timeNow.strftime('%d') + " - " + bln + " - " + timeNow.strftime('%Y') + "\nJam : [ " + timeNow.strftime('%H:%M:%S') + " ]"
                                if msg.to not in read['readPoint']:
                                    client.sendMessage(msg.to,"Lurking already off")
                                else:
                                    try:
                                            del read['readPoint'][msg.to]
                                            del read['readMember'][msg.to]
                                            del read['readTime'][msg.to]
                                    except:
                                          pass
                                    client.sendMessage(msg.to, "Delete reading point:\n" + readTime)
                
                        elif cmd == 'reset':
                                tz = pytz.timezone("Asia/Jakarta")
                                timeNow = datetime.now(tz=tz)
                                day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday", "Saturday"]
                                hari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"]
                                bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
                                hr = timeNow.strftime("%A")
                                bln = timeNow.strftime("%m")
                                for i in range(len(day)):
                                    if hr == day[i]: hasil = hari[i]
                                for k in range(0, len(bulan)):
                                    if bln == str(k): bln = bulan[k-1]
                                readTime = hasil + ", " + timeNow.strftime('%d') + " - " + bln + " - " + timeNow.strftime('%Y') + "\nJam : [ " + timeNow.strftime('%H:%M:%S') + " ]"
                                if msg.to in read["readPoint"]:
                                    try:
                                        read["readPoint"][msg.to] = True
                                        read["readMember"][msg.to] = {}
                                        read["readTime"][msg.to] = readTime
                                        read["ROM"][msg.to] = {}
                                    except:
                                        pass
                                    client.sendMessage(msg.to, "Reset reading point:\n" + readTime)
                                else:
                                    client.sendMessage(msg.to, "Lurking belum diaktifkan ngapain di reset?")
                                    
                        elif cmd == 'lurkers':
                                tz = pytz.timezone("Asia/Jakarta")
                                timeNow = datetime.now(tz=tz)
                                day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday", "Saturday"]
                                hari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"]
                                bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
                                hr = timeNow.strftime("%A")
                                bln = timeNow.strftime("%m")
                                for i in range(len(day)):
                                    if hr == day[i]: hasil = hari[i]
                                for k in range(0, len(bulan)):
                                    if bln == str(k): bln = bulan[k-1]
                                readTime = hasil + ", " + timeNow.strftime('%d') + " - " + bln + " - " + timeNow.strftime('%Y') + "\nJam : [ " + timeNow.strftime('%H:%M:%S') + " ]"
                                if receiver in read['readPoint']:
                                    if read["ROM"][receiver].items() == []:
                                        client.sendMessage(receiver,"[ Reader ]:\nNone")
                                    else:
                                        chiya = []
                                        for rom in read["ROM"][receiver].items():
                                            chiya.append(rom[1])
                                        cmem = client.getContacts(chiya) 
                                        zx = ""
                                        zxc = ""
                                        zx2 = []
                                        xpesan = 'Lurkers:\n'
                                    for x in range(len(cmem)):
                                        xname = str(cmem[x].displayName)
                                        pesan = ''
                                        pesan2 = pesan+"@c\n"
                                        xlen = str(len(zxc)+len(xpesan))
                                        xlen2 = str(len(zxc)+len(pesan2)+len(xpesan)-1)
                                        zx = {'S':xlen, 'E':xlen2, 'M':cmem[x].mid}
                                        zx2.append(zx)
                                        zxc += pesan2
                                    text = xpesan+ zxc + "\n「Lurking Tme」: \n" + readTime
                                    try:
                                        client.sendMessage(receiver, text, contentMetadata={'MENTION':str('{"MENTIONEES":'+json.dumps(zx2).replace(' ','')+'}')}, contentType=0)
                                    except Exception as error:
                                        print (error)
                                    pass
                                else:
                                    client.sendMessage(receiver,"「Lurking has not been set」")
#==========================================================================================                                
                        elif text.lower() == 'ceksider:on':
                            try:
                                del cctv['point'][receiver]
                                del cctv['sidermem'][receiver]
                                del cctv['cyduk'][receiver]
                            except:
                                pass
                            cctv['point'][receiver] = msg.id
                            cctv['sidermem'][receiver] = ""
                            cctv['cyduk'][receiver]=True
                            client.sendMessage(receiver, "「Cek sider enable」")
#==========================================================================================                          
                        elif text.lower() == 'ceksider:off':
                            if msg.to in cctv['point']:
                                cctv['cyduk'][receiver]=False
                                client.sendMessage(receiver, cctv['sidermem'][msg.to])
                            else:
                                client.sendMessage(receiver, "「Cek sider has not been set」")                                      
#============================================================================================
#==============================================================================================================
#           ||===========|| CCTV COMMANDS ||===========||
#========================================================================
#============================================================================================
#==============================================================================================================
                        elif cmd == "cctv on":
                            tz = pytz.timezone("Asia/Jakarta")
                            timeNow = datetime.now(tz=tz)
                            day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday", "Saturday"]
                            hari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"]
                            bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
                            hr = timeNow.strftime("%A")
                            bln = timeNow.strftime("%m")
                            for i in range(len(day)):
                                if hr == day[i]: hasil = hari[i]
                            for k in range(0, len(bulan)):
                                if bln == str(k): bln = bulan[k-1]
                            readTime = hasil + ", " + timeNow.strftime('%d') + " - " + bln + " - " + timeNow.strftime('%Y') + "\nJam : [ " + timeNow.strftime('%H:%M:%S') + " ]"
                            if to in read["readPoint"]:
                                client.sendMessage(to, "Cctv sudah aktif ketik {}Cctv result untuk menampilkan hasil".format(str(settings["keyCommand"])))
                            else:
                                try:
                                    read["readPoint"][to] = True
                                    read["readMember"][to] = {}
                                    read["readTime"][to] = readTime
                                    read["ROM"][to] = {}
                                except:
                                    pass
                                client.sendMessage(to, "Cctv diaktifkan ketik {}Cctv")
#======================================================================== # CCTV OFF
                        elif cmd == "cctv off":
                            if to in read["readPoint"]:
                                try:
                                    del read["readPoint"][to]
                                    del read["readMember"][to]
                                    del read["readTime"][to]
                                    del read["ROM"][to]
                                    client.sendMessage(to, "Berhasil matikan cctv")
                                except:
                                    pass
                            else:
                                client.sendMessage(to, "Cctv belum diaktifkan ngapain di matikan?")
#======================================================================== # RESET CCTV
                        elif cmd == "cctv reset":
                            tz = pytz.timezone("Asia/Jakarta")
                            timeNow = datetime.now(tz=tz)
                            day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday", "Saturday"]
                            hari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"]
                            bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
                            hr = timeNow.strftime("%A")
                            bln = timeNow.strftime("%m")
                            for i in range(len(day)):
                                if hr == day[i]: hasil = hari[i]
                            for k in range(0, len(bulan)):
                                if bln == str(k): bln = bulan[k-1]
                            readTime = hasil + ", " + timeNow.strftime('%d') + " - " + bln + " - " + timeNow.strftime('%Y') + "\nJam : [ " + timeNow.strftime('%H:%M:%S') + " ]"
                            if to in read["readPoint"]:
                                try:
                                    read["readPoint"][to] = True
                                    read["readMember"][to] = {}
                                    read["readTime"][to] = readTime
                                    read["ROM"][to] = {}
                                except:
                                    pass
                                client.sendMessage(to, "Cctv di reset")
                            else:
                                client.sendMessage(to, "Cctv belum diaktifkan ngapain di reset?")
#======================================================================== # RESULT CCTV
                        elif cmd == "cctv result":
                            if to not in read["readPoint"]:
                                client.sendMessage(to, "Cctv belum diaktifkan udah main result aja")
                            else:
                                ret_ = "╔══[ Reader ]"
                                reader = {}
                                reader["name"] = ""
                                if read["readMember"][to] == {}:
                                    reader["name"] += "\n╠ Belum ada yang membaca chat"
                                else:
                                    for a in read["readMember"][to]:
                                        reader["name"] += "\n╠ {}".format(str(read["readMember"][to][a]))
                                time_ = read["readTime"][to]
                                ret_ += reader["name"]
                                ret_ += "\n╠══[ Siders ]"
                                sider = {}
                                sider["name"] = ""
                                if read["ROM"][to] == {} and read["readMember"][to] != {}:
                                    for ar in read["readMember"][to]:
                                        contact = client.getContact(ar)
                                        sider["name"] += "\n╠ {}".format(str(contact.displayName))
                                elif read["ROM"][to] == {} and read["readMember"][to] == {}:
                                    pass
                                else:
                                    for ars in read["readMember"][to]:
                                        if ars not in read["ROM"][to]:
                                            contact = client.getContact(ars)
                                            sider["name"] += "\n╠ {}".format(str(contact.displayName))
                                tota = len(read["readMember"][to]) - len(read["ROM"][to])
                                totb = len(read["readMember"][to])
                                ret_ += sider["name"]
                                ret_ += "\n╚══[ Total {} Siders From {} Viewers ]".format(str(tota), str(totb))
                                ret_ += "\nPoint Set On : \n{}".format(str(time_))
                                client.sendMessage(to, str(ret_))
#============================================================================================
#==============================================================================================================
#           ||===========|| REMOTE COMMANDS ||===========||
#========================================================================
#============================================================================================
#==============================================================================================================
                        # Example remote command
                        elif cmd == "read on":
                            settings["autoRead"] = True
                            client.sendMessage(to, "「Auto read ENABLE」♪")
                        elif cmd == "read off":
                            settings["autoRead"] = False
                            client.sendMessage(to, "「Auto read DISABLE」♪")
                        elif cmd == "add on":
                            settings["autoAdd"] = True
                            client.sendMessage(to, "「Auto Add ENABLE」♪")
                        elif cmd == "add off":
                            settings["autoAdd"] = False
                            client.sendMessage(to, "「Auto Add DISABLE」♪")
                        elif cmd == "join on":
                            settings["autoJoin"] = True
                            client.sendMessage(to, "「Auto Join ENABLE」♪")
                        elif cmd == "join off":
                            settings["autoJoin"] = False
                            client.sendMessage(to, "「Auto Join DISABLE」♪")
                        elif cmd == "tag on":
                            settings["autotag"] = True
                            client.sendMessage(to, "「Auto Respon Tag ENABLE」♪")
                        elif cmd == "tag off":
                            settings["autotag"] = False
                            client.sendMessage(to, "「Auto Respon Tag DISABLE」♪")
                        elif cmd == "responpm on":
                            settings["responpm"] = True
                            client.sendMessage(to, "「Auto Respon PM ENABLE」♪")
                        elif cmd == "responpm off":
                            settings["responpm"] = False
                            client.sendMessage(to, "「Auto Respon PM DISABLE」♪")
                        elif cmd == "notag on":
                            settings["notag"] = True
                            client.sendMessage(to, "「Sock is on the door now fuck off.」♪")
                        elif cmd == "notag off":
                            settings["notag"] = False
                            client.sendMessage(to, "「Welp, fun is over now」♪")
                        elif cmd == "welcomemsg on":
                            settings["welcome"] = True
                            client.sendMessage(to, "「Welcome Message ENABLE」♪")
                        elif cmd == "welcomemsg off":
                            settings["welcome"] = False
                            client.sendMessage(to, "「Welcome Message DISABLE」♪")
                        elif cmd == "k on":
                            settings["contact"] = True
                            client.sendMessage(to, "「Display Contact ENABLE」♪")
                        elif cmd == "k off":
                            settings["contact"] = False
                            client.sendMessage(to, "「Display Contact DISABLE」♪")
                        elif cmd == "qr on":
                            settings["linkprotect"] = True
                            client.sendMessage(to, "「Protect URL ENABLE」♪")
                        elif cmd == "qr off":
                            settings["linkprotect"] = False
                            client.sendMessage(to, "「Protect URL DISABLE」♪")
                        elif cmd == "invite on":
                            settings["inviteprotect"] = True
                            client.sendMessage(to, "「Protect Invite ENABLE」♪")
                        elif cmd == "invite off":
                            settings["inviteprotect"] = False
                            client.sendMessage(to, "「Protect Invite DISABLE」♪")
                        elif cmd == "protectall on":
                            settings["Mprotection"] = True
                            client.sendMessage(to, "「Protect Whole Group」♪")
                        elif cmd == "protectall off":
                            settings["Mprotection"] = False
                            client.sendMessage(to, "「Protect Admin Only」♪")                            
                        elif cmd == "namelock on":
                            if msg.to in settings['pname']:
                                client.sendMessage(to,"「Protect Name Group ENABLE」♪")
                            else:
                                client.sendMessage(to,"「Protect Name Group ENABLE」♪")
                                settings['pname'][msg.to] = True
                                settings['pro_name'][msg.to] = client.getGroup(msg.to).name
                        elif cmd == "namelock off":
                            if msg.to in settings['pname']:
                                client.sendMessage(msg.to,"「Protect Name Group DISABLE」♪")
                                del settings['pname'][msg.to]
                            else:
                                client.sendMessage(msg.to,"「Protect Name Group DISABLE」♪")
                        elif cmd == "stkid on":
                            settings["sticker1"] = True
                            client.sendMessage(to, "「Detection sticker ENABLE」♪")
                        elif cmd == "stkid off":
                            settings["sticker1"] = False
                            client.sendMessage(to, "「Detection sticker DISABLE」♪")
                        elif cmd == "sticker on":
                            settings["sticker"] = True
                            client.sendMessage(to, "「Detection sticker ENABLE」♪")
                        elif cmd == "sticker off":
                            settings["sticker"] = False
                            client.sendMessage(to, "「Detection sticker DISABLE」♪")
                        elif cmd == "chatbot on":
                            settings["chat"] = True
                            client.sendMessage(to, "「Auto chat ENABLE」♪")
                        elif cmd == "chatbot off":
                            settings["chat"] = False
                            client.sendMessage(to, "「Auto chat DISABLE」♪")                            
#========================================================================
#============================================================================================
#==============================================================================================================
                        # Bonus fun command
                        elif cmd.startswith("image "):
                            start = time.time()
                            sep = msg.text.split(" ")
                            search = msg.text.replace(sep[0] + " ","")
                            url = "https://api.xeonwz.ga/api/image/google?q=" + urllib.parse.quote(search)
                            with requests.session() as web:
                                web.headers["User-Agent"] = random.choice(settings["userAgent"])
                                r = web.get(url)
                                data = r.text
                                data = json.loads(data)
                                if data["data"] != []:
                                    items = data["data"]
                                    path = random.choice(items)
                                    a = items.index(path)
                                    b = len(items)
                                    if settings["server"] == "VPS":
                                        client.sendImageWithURL(to, str(path))
                                    else:
                                        urllib.urlretrieve(path, "imgresult.jpg")
                                        client.sendImage(to, "imgresult.jpg")
                                    elapsed_time = time.time() - start
                                    client.sendMessage(msg.to, "[Image Result]\nImage #%s from #%s\nURL : %s\nDuration : %s" %(str(a),str(b),str(path),str(elapsed_time)))
                                else:
                                    client.sendMessage(msg.to, "[Image Result] Error : Image not found")
#========================================================================
                        elif 'searchimage' in msg.text.lower():
                             try:
                                 shi = text.lower().replace("searchimage ","")
                                 kha = random.choice(items)
                                 url = 'https://www.google.com/search?hl=en&biw=1366&bih=659&tbm=isch&sa=1&ei=vSD9WYimHMWHvQTg_53IDw&q=' + shi
                                 raw_html = (download_page(url))
                                 items = items + (raw_html)
                                 items = []
                             except:
                                 try:
                                     start = timeit.timeit()
                                     client.sendImageWithURL(to, random.choice(items))
                                     client.sendMessage(to, "Total Image Links ="+str(len(items)))
                                 except Exception as e:
                                     client.sendMessage(to, str(e))                                    
#=======================================================================
                        elif cmd.startswith('ig '):
                            try:                     
                                response = requests.get("https://www.instagram.com/"+instagram+"?__a=1")
                                data = response.json()
                                namaIG = str(data['user']['full_name'])
                                bioIG = str(data['user']['biography'])
                                mediaIG = str(data['user']['media']['count'])
                                verifIG = str(data['user']['is_verified'])
                                usernameIG = str(data['user']['username'])
                                followerIG = str(data['user']['followed_by']['count'])
                                profileIG = data['user']['profile_pic_url_hd']
                                privateIG = str(data['user']['is_private'])
                                followIG = str(data['user']['follows']['count'])
                                link = "Link: " + "https://www.instagram.com/" + instagram
                                detail = "========INSTAGRAM INFO USER========\n"
                                details = "\n========INSTAGRAM INFO USER========"
                                text = detail + "Name : "+namaIG+"\nUsername : "+usernameIG+"\nBiography : "+bioIG+"\nFollower : "+followerIG+"\nFollowing : "+followIG+"\nPost : "+mediaIG+"\nVerified : "+verifIG+"\nPrivate : "+privateIG+"" "\n" + link + details
                                client.sendImageWithURL(to, profileIG)
                                client.sendMessage(to, str(text))
                            except Exception as e:
                                client.sendMessage(to, str(e))
                                client.sendMessage(to,"Follow Fast Follback")
#============================================================================================
#==============================================================================================================
#           ||===========|| MEDIA COMMANDS ||===========||
#========================================================================
#============================================================================================
#==============================================================================================================
                        elif cmd.startswith("waktusalat "):
                            sep = text.split(" ")
                            location = text.replace(sep[0] + " ","")
                            with requests.session() as web:
                                web.headers["user-agent"] = random.choice(settings["userAgent"])
                                r = web.get("http://api.corrykalam.net/apisholat.php?lokasi={}".format(urllib.parse.quote(location)))
                                data = r.text
                                data = json.loads(data)
                                if data[1] != "Subuh : " and data[2] != "Dzuhur : " and data[3] != "Ashr : " and data[4] != "Maghrib : " and data[5] != "Isya' : ":
                                    ret_ = "╔══[ Prayer Schedule ]"
                                    ret_ += "\n╠ Lokasi : " + data[0]
                                    ret_ += "\n╠ " + data[1]
                                    ret_ += "\n╠ " + data[2]
                                    ret_ += "\n╠ " + data[3]
                                    ret_ += "\n╠ " + data[4]
                                    ret_ += "\n╠ " + data[5]
                                    ret_ += "\n╚══[ Complete ]"
                                else:
                                    ret_ = "[ Prayer Schedule ] Error : Location Not found!" 
                                client.sendMessage(to, str(ret_))
#======================================================================== # CHECK CUACA
                        elif cmd.startswith("cuaca "):
                            sep = text.split(" ")
                            location = text.replace(sep[0] + " ","")
                            with requests.session() as web:
                                web.headers["user-agent"] = random.choice(settings["userAgent"])
                                r = web.get("http://api.corrykalam.net/apicuaca.php?kota={}".format(urllib.parse.quote(location)))
                                data = r.text
                                data = json.loads(data)
                                if "result" not in data:
                                    ret_ = "╔══[ Weather Status ]"
                                    ret_ += "\n╠ Lokasi : " + data[0].replace("Temperatur di kota ","")
                                    ret_ += "\n╠ Suhu : " + data[1].replace("Suhu : ","")
                                    ret_ += "\n╠ Kelembaban : " + data[2].replace("Kelembaban : ","")
                                    ret_ += "\n╠ Tekanan Udara : " + data[3].replace("Tekanan udara : ","")
                                    ret_ += "\n╠ Kecepatan Angin : " + data[4].replace("Kecepatan angin : ","")
                                    ret_ += "\n╚══[ Complete ]"
                                else:
                                    ret_ = "[ Weather Status ] Error : Location Not found!"
                                client.sendMessage(to, str(ret_))
#======================================================================== # CHECK LOKASI
                        elif cmd.startswith("lokasi "):
                            sep = text.split(" ")
                            location = text.replace(sep[0] + " ","")
                            with requests.session() as web:
                                web.headers["user-agent"] = random.choice(settings["userAgent"])
                                r = web.get("http://api.corrykalam.net/apiloc.php?lokasi={}".format(urllib.parse.quote(location)))
                                data = r.text
                                data = json.loads(data)
                                if data[0] != "" and data[1] != "" and data[2] != "":
                                    link = "https://www.google.co.id/maps/@{},{},15z".format(str(data[1]), str(data[2]))
                                    ret_ = "╔══[ Details Location ]"
                                    ret_ += "\n╠ Lokasi : " + data[0]
                                    ret_ += "\n╠ Google Maps : " + link
                                    ret_ += "\n╚══[ Complete ]"
                                else:
                                    ret_ = "[ Details Location ] Error : Location Not found!"
                                client.sendMessage(to,str(ret_))
#======================================================================== # MUSIC MP3
                        elif cmd.startswith("music "):
                                sep = msg.text.split(" ")
                                textnya = msg.text.replace(sep[0] + " ","")
                                params = {'songname': textnya}
                                with requests.session() as web:
                                    web.headers["User-Agent"] = random.choice(settings["userAgent"])
                                    r = web.get("https://ide.fdlrcn.com/workspace/yumi-apis/joox?" + urllib.parse.urlencode(params))
                                    try:
                                        data = json.loads(r.text)
                                        for song in data:
                                            songs = song[5]
                                            lyric = songs.replace('ti:','Title - ')
                                            lyric = lyric.replace('ar:','Artist - ')
                                            lyric = lyric.replace('al:','Album - ')
                                            removeString = "[1234567890.:]"
                                            for char in removeString:
                                                lyric = lyric.replace(char,'')
                                            ret_ = "╔══[ Music and Lyric ]"
                                            ret_ += "\n╠ Nama lagu : {}".format(str(song[0]))
                                            ret_ += "\n╠ Durasi : {}".format(str(song[1]))
                                            ret_ += "\n╠ Link : {}".format(str(song[3]))
                                            ret_ += "\n╚══[ Finish ]\n{}".format(str(lyric))                                             
                                            client.sendMessage(msg.to, str(ret_))
                                            client.sendMessage(msg.to, "Please wait for audio")
                                            client.sendAudioWithURL(msg.to, song[3])
                                    except:
                                        client.sendMessage(msg.to, "Musik tidak ditemukan")
#======================================================================== # LINK YOUTUBE
                        elif cmd.startswith("youtube "):
                                sep = text.split(" ")
                                textnya = text.replace(sep[0] + " ","")
                                params = {'songname': textnya}
                                with requests.session() as web:
                                    web.headers["User-Agent"] = random.choice(settings["userAgent"])
                                    r = web.get("https://www.youtube.com/results", params = params)
                                    soup = BeautifulSoup(r.content, "html5lib")
                                    ret_ = "╔══[ Youtube Result ]"
                                    datas = []
                                    for data in soup.select(".yt-lockup-title > a[title]"):
                                        if "&lists" not in data["href"]:
                                            datas.append(data)
                                    for data in datas:
                                        ret_ += "\n╠══[ {} ]".format(str(data["title"]))
                                        ret_ += "\n╠ https://www.youtube.com{}".format(str(data["href"]))
                                    ret_ += "\n╚══[ Total {} ]".format(len(datas))
                                    client.sendMessage(msg.to, str(ret_))
                                    client.sendVideoWithURL(msg.to, str(data["href"]))
#======================================================================== # LIRIK LAGU
                        elif cmd.startswith("lyric "):
                                sep = msg.text.split(" ")
                                textnya = msg.text.replace(sep[0] + " ","")
                                params = {'songname': textnya}
                                with requests.session() as web:
                                    web.headers["User-Agent"] = random.choice(settings["userAgent"])
                                    r = web.get("https://ide.fdlrcn.com/workspace/yumi-apis/joox?" + urllib.parse.urlencode(params))
                                    try:
                                        data = json.loads(r.text)
                                        for song in data:
                                            songs = song[5]
                                            lyric = songs.replace('ti:','Title - ')
                                            lyric = lyric.replace('ar:','Artist - ')
                                            lyric = lyric.replace('al:','Album - ')
                                            removeString = "[1234567890.:]"
                                            for char in removeString:
                                                lyric = lyric.replace(char,'')
                                            ret_ = "╔══[ Lyric ]"
                                            ret_ += "\n╠ Nama lagu : {}".format(str(song[0]))
                                            ret_ += "\n╠ Durasi : {}".format(str(song[1]))
                                            ret_ += "\n╠ Link : {}".format(str(song[3]))
                                            ret_ += "\n╚══[ Finish ]\n{}".format(str(lyric))
                                            client.sendMessage(msg.to, str(ret_))
                                    except:
                                        client.sendMessage(msg.to, "Lirik tidak ditemukan")                                 
#======================================================================== # TEXT IMAGE
                        elif cmd.startswith("imagetext "):
                                sep = msg.text.split(" ")
                                textnya = msg.text.replace(sep[0] + " ","")
                                path = "http://chart.apis.google.com/chart?chs=480x80&cht=p3&chtt=" + textnya + "&chts=FFFFFF,70&chf=bg,s,000000"
                                client.sendImageWithURL(msg.to,path)
#========================================================================
                        elif cmd.startswith("mp4 "):
                            try:
                                sep = text.split(" ")
                                textToSearch = text.replace(sep[0] + " ","")
                                query = urllib.parse.quote(textToSearch)
                                url = "https://www.youtube.com/results?search_query=" + query
                                response = urllib.request.urlopen(url)
                                html = response.read()
                                soup = BeautifulSoup(html, "html.parser")
                                results = soup.find(attrs={'class':'yt-uix-tile-link'})
                                dl=("https://www.youtube.com" + results['href'])
                                vid = pafy.new(dl)
                                stream = vid.streams
                                for s in stream:
                                    vin = s.url
                                    hasil = "╔═════════════════[ Video ]"
                                    hasil += "\n╠ Title : {}".format(str(vid.title))
                                    hasil += "\n╠ Subscriber From : {}".format(str(vid.author))
                                    hasil += "\n╠ Please wait for the videos"
                                    hasil += "\n╚═════════════════[ Finish ]"
                                client.sendMessage(msg.to,hasil)
                                client.sendVideoWithURL(msg.to,vin)
                                print("[YOUTUBE]MP4 Succes")
                            except Exception as e:
                                client.sendMessage(to, str(e))                         
#============================================================================================
                        elif cmd.startswith("mp3 "):
                            try:
                                sep = text.split(" ")
                                textToSearch = text.replace(sep[0] + " ","")
                                query = urllib.parse.quote(textToSearch)
                                url = "https://www.youtube.com/results?search_query=" + query
                                response = urllib.request.urlopen(url)
                                html = response.read()
                                soup = BeautifulSoup(html, "html.parser")
                                results = soup.find(attrs={'class':'yt-uix-tile-link'})
                                dl=("https://www.youtube.com" + results['href'])
                                vid = pafy.new(dl)
                                stream = vid.streams
                                for s in stream:
                                    vin = s.url
                                    hasil = "╔═════════════════[ Audio ]"
                                    hasil += "\n╠ Title : {}".format(str(vid.title))
                                    hasil += "\n╠ Subscriber From : {}".format(str(vid.author))
                                    hasil += "\n╠ Please wait for the Audio"
                                    hasil += "\n╚═════════════════[ Finish ]"
                                client.sendMessage(msg.to,hasil)
                                client.sendAudioWithURL(msg.to,vin)
                                print("[YOUTUBE]MP4 Succes")
                            except Exception as e:
                                client.sendMessage(to, str(e))         
#==============================================================================================================
#           ||===========|| SELF SPECIAL COMMANDS ||===========||
#========================================================================
#============================================================================================
#==============================================================================================================
                        elif cmd == "liststicker":
                            with open('sticker.json','r') as fp:
                                stickers = json.load(fp)
                            ret_ = "╔══[ List Sticker ]"
                            for sticker in stickers:
                                ret_ += "\n╠ " + sticker.title()
                            ret_ += "\n╚══[ Total {} Stickers ]".format(str(len(stickers)))
                            client.sendMessage(to, ret_)
#======================================================================== # SPAM STICKER
                        elif cmd.startswith("spamsticker "):
                            sep = text.split(" ")
                            text = text.replace(sep[0] + " ","")
                            cond = text.split(" ")
                            jml = int(cond[0])
                            stickername = str(cond[1]).lower()
                            with open('sticker.json','r') as fp:
                                stickers = json.load(fp)
                            if stickername in stickers:
                                sid = stickers[stickername]["STKID"]
                                spkg = stickers[stickername]["STKPKGID"]
                            else:
                                return
                            for x in range(jml):
                                client.sendSticker(to, spkg, sid)
#======================================================================== #                                
                        elif cmd.startswith("spamtag "):
                            sep = text.split(" ")
                            text = text.replace(sep[0] + " ","")
                            cond = text.split(" ")
                            jml = int(cond[0])
                            if msg.toType == 2:
                                group = client.getGroup(to)
                            for x in range(jml):
                                if 'MENTION' in msg.contentMetadata.keys()!= None:
                                    names = re.findall(r'@(\w+)', text)
                                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                    mentionees = mention['MENTIONEES']
                                    lists = []
                                    for mention in mentionees:
                                        if mention["M"] not in lists:
                                            lists.append(mention["M"])
                                    for receiver in lists:
                                        contact = client.getContact(receiver)
                                        sendMention(to, receiver, "", "")
#======================================================================== #                                
                        elif cmd.startswith("spamgift "):
                            sep = text.split(" ")
                            text = text.replace(sep[0] + " ","")
                            cond = text.split(" ")
                            jml = int(cond[0])
                            if msg.toType == 2:
                                group = client.getGroup(to)
                            for x in range(jml):
                                if 'MENTION' in msg.contentMetadata.keys()!= None:
                                    names = re.findall(r'@(\w+)', text)
                                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                    mentionees = mention['MENTIONEES']
                                    lists = []
                                    for mention in mentionees:
                                        if mention["M"] not in lists:
                                            lists.append(mention["M"])
                                    for receiver in lists:
                                        contact = client.getContact(receiver)
                                        client.sendMessage(receiver, text=None, contentMetadata=None, contentType=9)                                                                   
#======================================================================== #                                
                        elif cmd.startswith("spamgift"):
                            sep = text.split(" ")
                            text = text.replace(sep[0] + " ","")
                            cond = text.split(" ")
                            jml = int(cond[0])                                                  
                            for x in range(jml):               
                                group = client.getGroup(msg.to)
                            for msg.to in lists:
                                client.sendMessage(to, text=None, contentMetadata=None, contentType=9)
#========================================================================                        
                        elif cmd.startswith("spam"):  
                            txt = text.split(" ")
                            jmlh = int(txt[2])
                            teks = text.replace("spam"+str(txt[1])+" "+str(jmlh)+" ","")
                            tulisan = jmlh * (teks+"\n")
                            if txt[1] == "on":
                                 if jmlh <= 900:
                                      for x in range(jmlh):
                                          client.sendMessage(to, teks)
                                 else:
                                      client.sendMessage(to, "Out of range! ")
                            elif txt[1] == "off":
                                 if jmlh <= 900:
                                      client.sendMessage(to, tulisan)
                                 else:
                                      client.sendMessage(to, "Out of range! ")                        
#======================================================================= # INVITE GROUP CALL
                        elif cmd.startswith("invgcall "):
                            sep = text.split(" ")
                            text = text.replace(sep[0] + " ","")
                            cond = text.split(" ")
                            jml = int(cond[0])
                            if msg.toType == 2:
                                group = client.getGroup(to)
                            for x in range(jml):
                                members = [mem.mid for mem in group.members]
                                call.acquireGroupCallRoute(to)
                                call.inviteIntoGroupCall(to, contactIds=members)
                            else:
                                client.sendMessage(to, "Invite {} group voicecall succes".format(str(jml)))
#======================================================================== # CHANGE PROFILE PICTURE
                        elif cmd == "update pict":
                            settings["changePicture"] = True
                            client.sendMessage(to, "「Please send picture to update」")
                        elif cmd == "cvp":
                            settings["changeVideo"] = True
                            client.sendMessage(to, "「Send Video」")
#========================================================================
                        elif cmd == "invite:on":
                            settings["winvite"] = True
                            client.sendMessage(to, "「Please send a contact to invite」")
#======================================================================== # CHANGE GROUP PICTURE
                        elif cmd == "update icon":
                            if msg.toType == 2:
                                if to not in settings["changeGroupPicture"]:
                                    settings["changeGroupPicture"].append(to)
                                client.sendMessage(to, "「please send picture to update」")
#========================================================================                
                elif msg.contentType == 13:
                    if settings["contact"] == True:
                        msg.contentType = 0
                        client.sendMessage(msg.to,msg.contentMetadata["mid"])
                        if 'displayName' in msg.contentMetadata:
                            contact = client.getContact(msg.contentMetadata["mid"])
                            try:
                                cu = channel.getProfileCoverURL(msg.contentMetadata["mid"])
                            except:
                                cu = ""
                            client.sendMessage(msg.to,"「DisplayName」:\n" + msg.contentMetadata["displayName"] + "\n[mid]:\n" + msg.contentMetadata["mid"] + "\n[statusMessage]:\n" + contact.statusMessage + "\n[pictureStatus]:\nhttp://dl.profile.line-cdn.net/" + contact.pictureStatus + "\n[coverURL]:\n" + str(cu))
                        else:
                            contact = client.getContact(msg.contentMetadata["mid"])
                            try:
                                cu = channel.getProfileCoverURL(msg.contentMetadata["mid"])
                            except:
                                cu = ""
                            if settings["server"] == "VPS":
                                client.sendMessage(msg.to,"「DisplayName」:\n" + contact.displayName + "\n[mid]:\n" + msg.contentMetadata["mid"] + "\n[statusMessage]:\n" + contact.statusMessage + "\n[pictureStatus]:\nhttp://dl.profile.line-cdn.net/" + contact.pictureStatus + "\n[coverURL]:\n" + str(cu))
                                client.sendImageWithURL(msg.to,"http://dl.profile.line-cdn.net/" + contact.pictureStatus)
                                client.sendImageWithURL(msg.to,str(cu))                                         
#========================================================================
                elif msg.contentType == 1:
                    if settings["changePicture"] == True:
                        path = client.downloadObjectMsg(msg_id)
                        settings["changePicture"] = False
                        client.updateProfilePicture(path)
                        client.sendMessage(to, "「Change profile picture succes」")
#========================================================================
                    if msg.toType == 2:
                        if to in settings["changeGroupPicture"]:
                            path = client.downloadObjectMsg(msg_id)
                            settings["changeGroupPicture"].remove(to)
                            client.updateGroupPicture(to, path)
                            client.sendMessage(to, "「Change picture group succes」")
                elif msg.contentType == 2:
                    if settings["changeVideo"] == True:
                        path = client.downloadObjectMsg(msg_id)
                        settings["changeVideo"] = False
                        client.updateProfileVideoPicture(path)
                        client.sendMessage(to, "Change profile video Succes")
#===================
#========================================================================
#============================================================================================
#==============================================================================================================
#           ||===========|| NOTIFIED RECEIVED MESSAGE ||===========||
#========================================================================
#============================================================================================
#==============================================================================================================
        if op.type == 26:
            print ("[ 26 ] RECEIVE MESSAGE")
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            if msg.toType == 0 or msg.toType == 2:
                if msg.toType == 0:
                    to = sender
                elif msg.toType == 2:
                    to = receiver
                if settings["autoRead"] == True:
                    client.sendChatChecked(to, msg_id)
                if 'MENTION' in msg.contentMetadata.keys()!=None:
                  if settings["autotag"] == True:
                     names = re.findall(r'@(\w+)',msg.text)
                     mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                     mentionees = mention['MENTIONEES']
                     for mention in mentionees:
                         if mention['M'] in clientMID:
                            sendMention(receiver, sender, "[Auto Respon]\nIs there anything I can help???", "\nWait a few more minutes I will respond to you because now I'm still busy .. thanks ,,")
                            break
#=============================================================================================
                if ("" in msg.text):
                    if settings["chat"] == True:
                      try:
                          tanya = text.replace("","")
                          jawab = ("Ya","Tidak ","mungkin saja","bisa jadi","gamau","jangan aku masih smp","hmm","ada apa kak?","diem","bawel lu","woiii berisik","ahhh","gue gamau","apaan dah","kenapa ?","nge LINE mulu, kapan nikah woi?","asdsawqfqioh","wqeiohoqhfifqjk","kamu siapa?","woi kikil bot, idiot lu","blablalbalbalbal","ekfjweifjf","dihhh","hmm","/bye","..","jangan rusuh","kamu kenapa kak","jgn gitu kak, ga baik","kakak kikil ya?","jgn ngikil mulu, kumpul duit sana nikah")
                          jawaban = random.choice(jawab)
                          sendMention(receiver, sender, jawaban, "")
                      except:
                          pass                            
#=============================================================================================                        
            if msg.contentType == 7:
                print ("[ 26 ] SEND STICKERS")
                if settings['sticker'] == True:
                    stk_id = msg.contentMetadata['STKID']
                    stk_ver = msg.contentMetadata['STKVER']
                    pkg_id = msg.contentMetadata['STKPKGID']
                    filler = "『 Sticker Check 』\nSTKID : %s\nSTKPKGID : %s\nSTKVER : %s\n『 Link 』\nline://shop/detail/%s" % (stk_id,pkg_id,stk_ver,pkg_id)
                    client.sendMessage(to, filler)                        
#========================================================================
                if 'MENTION' in msg.contentMetadata.keys()!=None:
                  if settings["responpm"] == True:
                     names = re.findall(r'@(\w+)',msg.text)
                     mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                     mentionees = mention['MENTIONEES']
                     for mention in mentionees:
                         if mention['M'] in clientMID:
                            sendMention(sender, sender, "[Auto Respon]\nIs there anything I can help???", "Please leave a message.....Thank you,,")
                            break
                            print("[NGENTOT]NGETAG")
#========================================================================
                if 'MENTION' in msg.contentMetadata.keys()!=None:
                  if settings["notag"] == True:
                     names = re.findall(r'@(\w+)',msg.text)
                     mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                     mentionees = mention['MENTIONEES']
                     for mention in mentionees:
                         if mention['M'] in clientMID:
                            sendMention(receiver, sender, "Berisik woyy..", "!?Dont tag me!!")
                            client.kickoutFromGroup(to,[msg._from])                         
                            break
#========================================================================                 
                if to in read["readPoint"]:
                    if sender not in read["ROM"][to]:
                        read["ROM"][to][sender] = True                            
#========================================================================
#============================================================================================            
#==============================================================================================================
        if op.type == 15:
            if settings["welcome"] == True:
                sendMention(op.param1, op.param2, "See you next time kak", "\nHati hati ya..!!")
        if op.type == 17:
            if settings["welcome"] == True:
                group = client.getGroup(op.param1)
                contact = client.getContact(op.param2)
                path = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
                client.sendImageWithURL(op.param1,path)
                client.sendMessage(op.param1, text=None, contentMetadata={'mid': op.param2}, contentType=13)
                sendMention(op.param1, op.param2, "Welcome kak", "\nBudayakan Membaca Note,salam,dan saling sapa ya kak..!!")
                client.sendMessage(op.param1, text=None, contentMetadata={"STKID": "3918721", "STKPKGID": "1095566", "STKVER": "100"}, contentType=7)                               
                print ("[ 17 ]  NOTIFIED ACCEPT GROUP INVITATION")
                #--_--#
                arg = "   Group Name : {}".format(str(group.name))
                arg += "\n   User Join : {}".format(str(contact.displayName))
                print (arg)                                       
#========================================================================
#===========================================================================================
        if op.type == 25:
            msg = op.message
            if msg.contentType == 13:
                if settings["wblacklist"] == True:
                    if msg.contentMetadata["mid"] in settings["blacklist"]:
                        client.sendMessage(to,"「Done」")
                        settings["wblacklist"] = False
                    else:
                        settings["blacklist"][msg.contentMetadata["mid"]] = True
                        settings["wblacklist"] = False
                        client.sendMessage(to,"「Done」")
                elif settings["dblacklist"] == True:
                    if msg.contentMetadata["mid"] in settings["blacklist"]:
                        del settings["blacklist"][msg.contentMetadata["mid"]]
                        client.sendMessage(to,"「Done」")
                        settings["dblacklist"] = False
                    else:
                        settings["dblacklist"] = False
                        client.sendMessage(to,"「Done」")                                                 
#============================================================================================
            if msg.contentType == 7:
                print ("[ 25 ] SEND STICKERS")
                if settings['sticker1'] == True:
                    stk_id = msg.contentMetadata['STKID']
                    stk_ver = msg.contentMetadata['STKVER']
                    pkg_id = msg.contentMetadata['STKPKGID']
                    filler = "『 Sticker Check 』\nSTKID : %s\nSTKPKGID : %s\nSTKVER : %s\n『 Link 』\nline://shop/detail/%s" % (stk_id,pkg_id,stk_ver,pkg_id)
                    client.sendMessage(to, filler)
#==============================================================================================================
            if msg.contentType == 13:
                if settings["winvite"] == True:           
                        _name = msg.contentMetadata["displayName"]
                        invite = msg.contentMetadata["mid"]
                        groups = client.getGroup(to)
                        pending = groups.invitee
                        targets = []
                        for s in groups.members:
                            if _name in s.displayName:
                                client.sendMessage(to,"「Users DisplayName " + _name + " Already in Group」")
                                break
                            elif invite in settings["blacklist"]:
                                client.sendMessage(to,"Sorry, " + _name + " It's in Blacklist")
                                client.sendMessage(to,"「Invited Canceled」\n「Please Unban " + invite + " 」")
                                break                             
                            else:
                                targets.append(invite)
                        if targets == []:
                            pass
                        else:
                            for target in targets:
                                try:   
                                    client.findAndAddContactsByMid(target)
                                    client.inviteIntoGroup(to,[target])
                                    client.sendMessage(to,"°「Invited」\n°「Succes Invite " + _name + " 」")
                                    settings["winvite"] = False
                                    break
                                except:
                                    try:
                                        client.findAndAddContactsByMid(target)
                                        client.inviteIntoGroup(op.param1,[invite])
                                        settings["winvite"] = False
                                    except:
                                        client.sendMessage(to,"「Error, Limited Send Group Invitation」")
                                        settings["winvite"] = False
#=================================================================================
#==============================================================================================================
#           ||===========|| NOTIFIED READ MESSAGE ||===========||
#========================================================================
#============================================================================================
#==========================================================================================
        if op.param3 == "1":
            if op.param1 in protectname:
                group = client.getGroup(op.param1)
                try:
                    group.name = settings["pro_name"][op.param1]
                    client.updateGroup(group)
                    client.sendMessage(op.param1, "Groupname protect now")
                    settings["blacklist"][op.param2] = True
                    f=codecs.open('st2__b.json','w','utf-8')
                    json.dump(settings["blacklist"], f, sort_keys=True, indent=4,ensure_ascii=False)
                except Exception as e:
                    print (e)
                    pass
#==============================================================================================================
        if op.type == 55:
            print ("[ 55 ] NOTIFIED READ MESSAGE")
            if op.param1 in read["readPoint"]:
                _name = client.getContact(op.param2).displayName
                tz = pytz.timezone("Asia/Jakarta")
                timeNow = datetime.now(tz=tz)
                timeHours = datetime.strftime(timeNow," (%H:%M)")
                read["readMember"][op.param1][op.param2] = str(_name) + str(timeHours)
        backupData()
    except Exception as error:
        logError(error)
        
        if op.type == 55:
                print ("[ 55 ] NOTIFIED READ MESSAGE")
                try:
                    if op.param1 in read['readPoint']:
                        if op.param2 in read['readMember'][op.param1]:
                            pass
                        else:
                            read['readMember'][op.param1] += op.param2
                        read['ROM'][op.param1][op.param2] = op.param2
                    else:
                       pass
                except:
                    pass

        if op.type == 55:
                print ("[ 55 ] NOTIFIED READ MESSAGE")
                try:
                    if cctv['cyduk'][op.param1]==True:
                        if op.param1 in cctv['point']:
                            Name = client.getContact(op.param2).displayName
                            if Name in cctv['sidermem'][op.param1]:
                                pass
                            else:
                                cctv['sidermem'][op.param1] += "\n~ " + Name
                                zxn=["Hey Jangan sider "," Jangan sider ","Halo ayo kita ngobrol ","Turun kak ikut chat ","Sider mulu ","sider tak doakan jones ","Ciyyee yang lagi ngintip ","Hai Kang ngintip ","Jangan sider mulu dong kk "]
                                client.sendMessage(op.param1, str(random.choice(zxn))+' '+Name)                                                              
                                dhil(op.param1,[op.param2])
                        else:
                            pass
                    else:
                        pass
                except:
                    pass
        else:
            pass                 
#========================================================================
#============================================================================================
#==============================================================================================================
#           ||===========|| DONE ||===========||
#========================================================================
#============================================================================================
#==============================================================================================================

while True:
    try:
        autoRestart()
        ops = clientPoll.singleTrace(count=50)
        if ops is not None:
            for op in ops:
                clientBot(op)
                # Don't remove this line, if you wan't get error soon!
                clientPoll.setRevision(op.revision)
    except Exception as e:
        logError(e)
